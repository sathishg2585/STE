window.CKEDITOR_BASEPATH = '/profiles/publisher/libraries/ckeditor/';;
